﻿namespace TestingMVC.Models
{
    public class RedirectionTAB
    {
        public string? Name { get; set; }
        public string? FormUrl { get; set; }
        public string? TabIcon { get; set; }
        public bool? IsActive { get; set; }
    }
}
