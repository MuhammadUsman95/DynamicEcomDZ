﻿namespace TestingMVC.Models
{
    public class CustomerModel
    {
        public int CustomerId { get; set; }
        public string Customer { get; set; }
        public string ImagePath { get; set; }
        public int Rating { get; set; }
    }
}
